<!--login form -->
<div class="login-form-container">
   <div id="close-login-btn" class="fas- fa-times"></div>
   <form action="">
       <h3>Sign in</h3>
       <span>username</span>
       <input type="email" name="" placeholder="enter your email" id="">
       <span>password</span>
       <input type="password" name="" placeholder="enter your password" id="">
       <div class="checkbox">
           <input type="checkbox" name="" id="remember-me">
           <label for="remember-me"> remeber me</label>
       </div>
       <input type="submit" value="sign in" class="btn">
       <p>Nakalimutan ang password ? <a href="#">Pindutin ito</a></p>
       <p>Gumawa ng Account ? <a href="#">Gumawa</a></p>
   </form>
</div>
<!--login form -->