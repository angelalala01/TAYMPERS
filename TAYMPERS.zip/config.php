<?php

$conn = mysqli_connect('localhost','root','','taympers_db') or die('connection failed');

?>